package Model;

public class Conta {
   public double saldo;
   public double valor;


    public void deposita(double valor) {
        saldo = valor + saldo;
    }

    public void saca(double valor) {
        if (valor <= saldo) {
            saldo -= valor;
        } else {
            System.out.println("Saldo insuficiente.");
        }
    }

    public void atualiza(double taxa) {
        saldo += saldo * taxa;
    }

    //MET
    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
}

