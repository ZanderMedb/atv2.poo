package Model;

public class ContaCorrente extends Conta {

    public void depositaCC(double valor) {
        saldo += valor - 0.10;
    }

    public void atualizaCC(double taxa) {
        saldo += saldo * (2 * taxa);
    }
}

