package Model;

public class ContaPoupanca extends Conta {

    public void atualizaCP(double taxa) {
        saldo += saldo * (3 * taxa);
    }
}

