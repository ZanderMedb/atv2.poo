package Control;

import Model.Conta;
import Model.ContaCorrente;
import Model.ContaPoupanca;
import View.view;

public class control {
    private view view;
    private Conta conta;

    public control(Conta conta) {
        this.view = new view();
        this.conta = conta;
    }

    public void iniciar() {
        int opcao;
        do {
            opcao = view.mostrarMenu();
            switch (opcao) {
                case 1:
                    double valorDeposito = view.solicitarValor("Digite o valor para depósito: ");
                    if (conta instanceof ContaCorrente) {
                        ((ContaCorrente) conta).depositaCC(valorDeposito);
                    } else if (conta instanceof ContaPoupanca) {
                        conta.deposita(valorDeposito);
                    }
                    break;

                case 2:
                    double valorSaque = view.solicitarValor("Digite o valor para saque: ");
                    conta.saca(valorSaque);
                    break;

                case 3:
                    double taxa = view.solicitarValor("Digite a taxa de atualização: ");
                    if (conta instanceof ContaCorrente) {
                        ((ContaCorrente) conta).atualizaCC(taxa);
                    } else if (conta instanceof ContaPoupanca) {
                        ((ContaPoupanca) conta).atualizaCP(taxa);
                    } else {
                        conta.atualiza(taxa);
                    }
                    break;

                case 4:
                    view.mostrarSaldo(conta.getSaldo());
                    break;

                case 5:
                    view.mostrarMensagem("Saindo...");
                    break;

                default:
                    view.mostrarMensagem("Opção inválida. Tente novamente.");
                    break;
            }
        } while (opcao != 5);
    }
}
