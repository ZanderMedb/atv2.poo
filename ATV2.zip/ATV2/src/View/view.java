package View;

import java.util.Scanner;

public class view {
    private Scanner scanner;

    public view() {
        scanner = new Scanner(System.in);
    }

    public int mostrarMenu() {
        System.out.println("Menu:");
        System.out.println("1. Depositar");
        System.out.println("2. Sacar");
        System.out.println("3. Atualizar saldo");
        System.out.println("4. Mostrar saldo");
        System.out.println("5. Sair");
        System.out.print("Escolha uma opção: ");
        return scanner.nextInt();
    }

    public double solicitarValor(String mensagem) {
        System.out.print(mensagem);
        return scanner.nextDouble();
    }

    public void mostrarSaldo(double saldo) {
        System.out.println("Saldo atual: " + saldo);
    }

    public void mostrarMensagem(String mensagem) {
        System.out.println(mensagem);
    }
}
