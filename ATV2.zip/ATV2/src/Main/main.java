package Main;

import Control.control;
import Model.Conta;
import Model.ContaCorrente;
import Model.ContaPoupanca;
import View.view;

public class main {
    public static void main(String[] args) {

        Conta contac = new ContaCorrente();
        ContaPoupanca contap = new ContaPoupanca();
        control contacontrol = new control(contac);
        contacontrol.iniciar();
    }
}
